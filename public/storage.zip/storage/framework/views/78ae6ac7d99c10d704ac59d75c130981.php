<?php if (isset($component)) { $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb = $attributes; } ?>
<?php $component = App\View\Components\ServerLayout::resolve(['server' => $server] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('server-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ServerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> <?php echo e($server->name); ?> - Metrics <?php $__env->endSlot(); ?>

    <div class="space-y-4">
        <div class="flex items-center justify-between">
            <?php echo $__env->make("metrics.partials.filter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("metrics.partials.data-retention", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php
            $cpuSets = [
                "name" => "CPU Load",
                "data" => $data["metrics"]->pluck("load")->toArray(),
                "color" => "#ff9900",
            ];
            $memorySets = [
                "name" => "Memory Usage",
                "data" => $data["metrics"]->pluck("memory_used")->toArray(),
                "color" => "#3366cc",
            ];
            $diskSets = [
                "name" => "Disk Usage",
                "data" => $data["metrics"]->pluck("disk_used")->toArray(),
                "color" => "#109618",
            ];
        ?>

        <div class="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <?php if (isset($component)) { $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chart','data' => ['id' => 'cpu-load','type' => 'area','title' => 'CPU Load','sets' => [$cpuSets],'categories' => $data['metrics']->pluck('date')->toArray(),'color' => '#ff9900','class' => 'h-[200px] !p-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'cpu-load','type' => 'area','title' => 'CPU Load','sets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([$cpuSets]),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['metrics']->pluck('date')->toArray()),'color' => '#ff9900','class' => 'h-[200px] !p-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $attributes = $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $component = $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chart','data' => ['id' => 'memory-usage','type' => 'area','title' => 'Memory','sets' => [$memorySets],'categories' => $data['metrics']->pluck('date')->toArray(),'color' => '#3366cc','formatter' => 'function (value) { return (value / 1000).toFixed(2) + ` MB`; }','class' => 'h-[200px] !p-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'memory-usage','type' => 'area','title' => 'Memory','sets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([$memorySets]),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['metrics']->pluck('date')->toArray()),'color' => '#3366cc','formatter' => 'function (value) { return (value / 1000).toFixed(2) + ` MB`; }','class' => 'h-[200px] !p-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $attributes = $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $component = $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chart','data' => ['id' => 'disk-usage','type' => 'area','title' => 'Disk','sets' => [$diskSets],'categories' => $data['metrics']->pluck('date')->toArray(),'formatter' => 'function (value) { return value + ` MB`; }','color' => '#109618','class' => 'h-[200px] !p-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'disk-usage','type' => 'area','title' => 'Disk','sets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([$diskSets]),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['metrics']->pluck('date')->toArray()),'formatter' => 'function (value) { return value + ` MB`; }','color' => '#109618','class' => 'h-[200px] !p-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $attributes = $__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__attributesOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4)): ?>
<?php $component = $__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4; ?>
<?php unset($__componentOriginalc621b3f3a1dd664e2d7a5c269bd63ea4); ?>
<?php endif; ?>
        </div>

        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div class="grid grid-cols-1 gap-4">
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Total Memory</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->memory_total : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Used Memory</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->memory_used : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Free Memory</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->memory_free : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
            </div>
            <div class="grid grid-cols-1 gap-4">
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Total Space</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->disk_total : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Used Space</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->disk_used : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'grid grid-cols-1 gap-4 lg:grid-cols-2']); ?>
                    <span class="text-center lg:text-left">Free Space</span>
                    <div class="text-center text-xl font-bold text-gray-600 dark:text-gray-400 lg:text-right">
                        <?php echo e($lastMetric ? $lastMetric->disk_free : "-"); ?> MB
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent("modals"); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $attributes = $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $component = $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/metrics/index.blade.php ENDPATH**/ ?>