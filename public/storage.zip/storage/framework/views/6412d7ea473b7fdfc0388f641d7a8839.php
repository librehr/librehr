<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "open" => false,
    "align" => "right",
    "width" => "48",
    "contentClasses" => "list-none divide-y divide-gray-100 rounded-md bg-white text-base dark:divide-gray-600 dark:bg-gray-700",
    "search" => false,
    "searchUrl" => "",
    "hideIfEmpty" => false,
    "closeOnClick" => true,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "open" => false,
    "align" => "right",
    "width" => "48",
    "contentClasses" => "list-none divide-y divide-gray-100 rounded-md bg-white text-base dark:divide-gray-600 dark:bg-gray-700",
    "search" => false,
    "searchUrl" => "",
    "hideIfEmpty" => false,
    "closeOnClick" => true,
]); ?>
<?php foreach (array_filter(([
    "open" => false,
    "align" => "right",
    "width" => "48",
    "contentClasses" => "list-none divide-y divide-gray-100 rounded-md bg-white text-base dark:divide-gray-600 dark:bg-gray-700",
    "search" => false,
    "searchUrl" => "",
    "hideIfEmpty" => false,
    "closeOnClick" => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    if (! $hideIfEmpty) {
        $contentClasses .= " py-1 border border-gray-200 dark:border-gray-600";
    }

    switch ($align) {
        case "left":
            $alignmentClasses = "left-0 origin-top-left";
            break;
        case "top":
            $alignmentClasses = "origin-top";
            break;
        case "right":
        default:
            $alignmentClasses = "right-0 origin-top-right";
            break;
    }

    switch ($width) {
        case "48":
            $width = "w-48";
            break;
        case "56":
            $width = "w-56";
            break;
        case "full":
            $width = "w-full";
            break;
    }
?>

<div class="relative" x-data="{ open: <?php echo \Illuminate\Support\Js::from($open)->toHtml() ?> }" @click.outside="open = false" @close.stop="open = false">
    <div @click="open = ! open">
        <?php echo e($trigger); ?>

    </div>

    <div
        x-show="open"
        x-transition:enter="transition duration-200 ease-out"
        x-transition:enter-start="scale-95 transform opacity-0"
        x-transition:enter-end="scale-100 transform opacity-100"
        x-transition:leave="transition duration-75 ease-in"
        x-transition:leave-start="scale-100 transform opacity-100"
        x-transition:leave-end="scale-95 transform opacity-0"
        class="<?php echo e($width); ?> <?php echo e($alignmentClasses); ?> absolute z-50 mt-2 rounded-md"
        style="display: none"
        <?php if($closeOnClick): ?> @click="open = false" <?php endif; ?>
    >
        <div class="<?php echo e($contentClasses); ?> rounded-md">
            <?php echo e($content); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/dropdown.blade.php ENDPATH**/ ?>