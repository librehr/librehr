<div class="space-y-6">
    <?php if (isset($component)) { $__componentOriginal91c4f2e79abed26018755b4f5085cb05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91c4f2e79abed26018755b4f5085cb05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.live','data' => ['id' => 'live-server']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'live-server']); ?>
        <?php if($server->status === \App\Enums\ServerStatus::INSTALLING): ?>
            <?php echo $__env->make("servers.partials.installing", ["server" => $server], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if($server->status === \App\Enums\ServerStatus::INSTALLATION_FAILED): ?>
            <?php echo $__env->make("servers.partials.installation-failed", ["server" => $server], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if(in_array($server->status, [\App\Enums\ServerStatus::READY, \App\Enums\ServerStatus::DISCONNECTED])): ?>
            <div class="space-y-10">
                <?php echo $__env->make("servers.partials.server-overview", ["server" => $server], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91c4f2e79abed26018755b4f5085cb05)): ?>
<?php $attributes = $__attributesOriginal91c4f2e79abed26018755b4f5085cb05; ?>
<?php unset($__attributesOriginal91c4f2e79abed26018755b4f5085cb05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91c4f2e79abed26018755b4f5085cb05)): ?>
<?php $component = $__componentOriginal91c4f2e79abed26018755b4f5085cb05; ?>
<?php unset($__componentOriginal91c4f2e79abed26018755b4f5085cb05); ?>
<?php endif; ?>

    <?php echo $__env->make("server-logs.partials.logs-list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/servers/partials/show-server.blade.php ENDPATH**/ ?>