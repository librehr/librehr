<td
    <?php echo $attributes->merge(["class" => "text-sm whitespace-nowrap px-6 py-4 text-gray-700 dark:text-gray-300 w-1"]); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /var/www/html/resources/views/components/td.blade.php ENDPATH**/ ?>