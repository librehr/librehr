<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "active",
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "active",
]); ?>
<?php foreach (array_filter(([
    "active",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $class =
        "flex w-full cursor-pointer items-center justify-center rounded-md border-2 bg-primary-50 px-3 pb-2 pt-3 dark:bg-primary-500 dark:bg-opacity-10";
    $classes =
        $active ?? false
            ? $class . " border-primary-600"
            : $class . " border-primary-200 dark:border-primary-600 dark:border-opacity-20";
?>

<a <?php echo e($attributes->merge(["class" => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH /var/www/html/resources/views/components/server-provider-item.blade.php ENDPATH**/ ?>