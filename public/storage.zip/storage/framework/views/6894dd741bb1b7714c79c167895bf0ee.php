<div>
    <?php if($site->status === \App\Enums\SiteStatus::INSTALLING): ?>
        <?php echo $__env->make("sites.partials.installing", ["site" => $site], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("server-logs.partials.logs-list", ["server" => $site->server, "site" => $site], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($site->status === \App\Enums\SiteStatus::INSTALLATION_FAILED): ?>
        <?php echo $__env->make("sites.partials.installation-failed", ["site" => $site], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("server-logs.partials.logs-list", ["server" => $site->server, "site" => $site], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($site->status === \App\Enums\SiteStatus::READY): ?>
        <?php echo $__env->make("application." . $site->type . "-app", ["site" => $site], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/resources/views/sites/partials/show-site.blade.php ENDPATH**/ ?>