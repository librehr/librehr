<div id="toast" hx-swap-oob="true">
    <script>
        window.addEventListener('toast', (e) => {
            window.toastr[e.detail.type](e.detail.message);
        });
    </script>
    <?php if(session()->has("toast.type") && session()->has("toast.message")): ?>
        <script defer>
            if (window.toastr) {
                window.toastr['<?php echo e(session()->get("toast.type")); ?>']('<?php echo e(session()->get("toast.message")); ?>');
            }
            document.addEventListener('DOMContentLoaded', () => {
                window.toastr['<?php echo e(session()->get("toast.type")); ?>']('<?php echo e(session()->get("toast.message")); ?>');
            });
        </script>
    <?php endif; ?>
</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/toast.blade.php ENDPATH**/ ?>