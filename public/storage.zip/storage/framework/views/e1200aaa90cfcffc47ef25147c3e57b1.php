<div <?php echo $attributes->merge(["class" => "max-w-5xl mx-auto"]); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/html/resources/views/components/container.blade.php ENDPATH**/ ?>