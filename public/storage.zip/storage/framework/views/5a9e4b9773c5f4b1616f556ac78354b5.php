<div
    <?php echo $attributes->merge(["class" => "bg-white border boarder-gray-200 dark:border-gray-700 dark:bg-gray-800 p-6 rounded-md"]); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/simple-card.blade.php ENDPATH**/ ?>