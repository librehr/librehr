<th
    <?php echo $attributes->merge(["class" => "whitespace-nowrap bg-gray-50 px-6 py-3 text-left text-xs font-medium uppercase leading-4 tracking-wider text-gray-500 dark:bg-gray-700 dark:text-gray-400"]); ?>

>
    <?php echo e($slot); ?>

</th>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/th.blade.php ENDPATH**/ ?>