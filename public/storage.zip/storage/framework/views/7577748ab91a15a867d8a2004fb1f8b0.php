<?php if (isset($component)) { $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb = $attributes; } ?>
<?php $component = App\View\Components\ServerLayout::resolve(['server' => $server] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('server-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ServerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> <?php echo e(__("PHP")); ?> <?php $__env->endSlot(); ?>

    <?php $__errorArgs = ["version"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php if (isset($component)) { $__componentOriginal46831ae04810aa678ae1b1e46c115fd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46831ae04810aa678ae1b1e46c115fd6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('version')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('version'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46831ae04810aa678ae1b1e46c115fd6)): ?>
<?php $attributes = $__attributesOriginal46831ae04810aa678ae1b1e46c115fd6; ?>
<?php unset($__attributesOriginal46831ae04810aa678ae1b1e46c115fd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46831ae04810aa678ae1b1e46c115fd6)): ?>
<?php $component = $__componentOriginal46831ae04810aa678ae1b1e46c115fd6; ?>
<?php unset($__componentOriginal46831ae04810aa678ae1b1e46c115fd6); ?>
<?php endif; ?>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php echo $__env->make("php.partials.installed-versions", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($server->defaultService("php")): ?>
        <?php echo $__env->make("php.partials.default-cli", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $attributes = $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $component = $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/php/index.blade.php ENDPATH**/ ?>