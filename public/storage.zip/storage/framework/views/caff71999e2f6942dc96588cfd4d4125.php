<?php if (isset($component)) { $__componentOriginald72b611fc1551d064816ce6ce4b3b59b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald72b611fc1551d064816ce6ce4b3b59b = $attributes; } ?>
<?php $component = App\View\Components\SettingsLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('settings-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SettingsLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> <?php echo e(__("SSH Keys")); ?> <?php $__env->endSlot(); ?>

    <?php echo $__env->make("settings.ssh-keys.partials.keys-list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald72b611fc1551d064816ce6ce4b3b59b)): ?>
<?php $attributes = $__attributesOriginald72b611fc1551d064816ce6ce4b3b59b; ?>
<?php unset($__attributesOriginald72b611fc1551d064816ce6ce4b3b59b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald72b611fc1551d064816ce6ce4b3b59b)): ?>
<?php $component = $__componentOriginald72b611fc1551d064816ce6ce4b3b59b; ?>
<?php unset($__componentOriginald72b611fc1551d064816ce6ce4b3b59b); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/settings/ssh-keys/index.blade.php ENDPATH**/ ?>