<div>
    <div
        id="<?php echo e($id); ?>"
        <?php echo e($attributes->merge(["class" => "mt-1 min-h-[400px] w-full"])); ?>

        class="ace-vito ace_dark"
    ></div>
    <textarea id="textarea-<?php echo e($id); ?>" name="<?php echo e($name); ?>" style="display: none"></textarea>
    <script>
        if (window.initAceEditor) {
            window.initAceEditor(<?php echo json_encode($options, 15, 512) ?>);
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                window.initAceEditor(<?php echo json_encode($options, 15, 512) ?>);
            });
        }
    </script>
</div>
<?php /**PATH /var/www/html/resources/views/components/editor.blade.php ENDPATH**/ ?>