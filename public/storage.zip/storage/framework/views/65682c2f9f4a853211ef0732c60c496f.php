<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "id",
    "type",
    "title",
    "color",
    "sets",
    "categories",
    "toolbar" => false,
    "formatter" => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "id",
    "type",
    "title",
    "color",
    "sets",
    "categories",
    "toolbar" => false,
    "formatter" => null,
]); ?>
<?php foreach (array_filter(([
    "id",
    "type",
    "title",
    "color",
    "sets",
    "categories",
    "toolbar" => false,
    "formatter" => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => ['attributes' => $attributes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>
    <div class="relative">
        <div class="absolute left-4 top-4"><?php echo e($title); ?></div>
    </div>
    <div id="<?php echo e($id); ?>" class="pt-4"></div>
    <script>
        window.addEventListener('load', function () {
            let options = {
                series: [
                    <?php $__currentLoopData = $sets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            name: '<?php echo e($set["name"]); ?>',
                            data: <?php echo json_encode($set["data"], 15, 512) ?>,
                            color: '<?php echo e($set["color"]); ?>'
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                chart: {
                    height: '100%',
                    maxWidth: '100%',
                    type: '<?php echo e($type); ?>',
                    fontFamily: 'Inter, sans-serif',
                    dropShadow: {
                        enabled: false
                    },
                    toolbar: {
                        show: <?php echo \Illuminate\Support\Js::from($toolbar)->toHtml() ?>
                    }
                },
                tooltip: {
                    enabled: true,
                    x: {
                        show: true
                    }
                },
                legend: {
                    show: true
                },
                <?php if($type == 'area'): ?>
                fill: {
                    type: 'gradient',
                    gradient: {
                        opacityFrom: 0.55,
                        opacityTo: 0,
                        shade: '<?php echo e($color); ?>',
                        gradientToColors: ['<?php echo e($color); ?>']
                    }
                },
                <?php endif; ?>
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    width: 2,
                    curve: 'smooth'
                },
                grid: {
                    show: false,
                    strokeDashArray: 4,
                    padding: {
                        left: 2,
                        right: 2,
                        top: 0
                    }
                },
                xaxis: {
                    categories: <?php echo json_encode($categories, 15, 512) ?>,
                    labels: {
                        show: false
                    },
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false
                    }
                },
                yaxis: {
                    show: false,
                    labels: {
                        <?php if($formatter): ?>
                        formatter: <?php echo e($formatter); ?>,
                        <?php endif; ?>
                    }
                }
            };

            if (document.getElementById('<?php echo e($id); ?>') && typeof ApexCharts !== 'undefined') {
                const chart = new ApexCharts(document.getElementById('<?php echo e($id); ?>'), options);
                chart.render();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/chart.blade.php ENDPATH**/ ?>