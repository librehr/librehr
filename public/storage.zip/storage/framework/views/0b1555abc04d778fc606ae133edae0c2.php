<tr
    <?php echo $attributes->merge(["class" => "dark:text-white bg-white border-b last:border-b-0 dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/70"]); ?>

>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH /var/www/html/resources/views/components/tr.blade.php ENDPATH**/ ?>