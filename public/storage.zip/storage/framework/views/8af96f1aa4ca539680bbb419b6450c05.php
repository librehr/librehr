<?php
    use App\Enums\ServerStatus;
?>

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "server",
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "server",
]); ?>
<?php foreach (array_filter(([
    "server",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace("_", "-", app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" hx-swap-oob="true" />

        <title>
            <?php if(isset($pageTitle)): ?>  <?php echo e($pageTitle); ?> -
            <?php endif; ?> <?php echo e(config("app.name", "Laravel")); ?>

        </title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net" />
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <?php echo $__env->make("layouts.partials.favicon", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(["resources/css/app.css", "resources/js/app.js"]); ?>
    </head>

    <body class="bg-gray-50 font-sans antialiased dark:bg-gray-900 dark:text-gray-300" x-data="" x-cloak>
        <?php echo $__env->make("layouts.partials.search", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("layouts.navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("layouts.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="mt-[64px] w-full"></div>

        <div class="sm:ml-64">
            <?php if(isset($header)): ?>
                <header class="border-b border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
                    <div class="mx-auto flex h-20 w-full max-w-full items-center justify-between px-5">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <?php if(isset($header2)): ?>
                <header class="border-b border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
                    <div class="mx-auto max-w-full px-5 py-6">
                        <?php echo e($header2); ?>

                    </div>
                </header>
            <?php endif; ?>

            <div class="px-4 py-10">
                <?php echo e($slot); ?>

            </div>
        </div>

        <script>
            // On page load or when changing themes, best to add inline in `head` to avoid FOUC
            if (
                localStorage.theme === 'dark' ||
                (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)
            ) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        </script>
        <?php if (isset($component)) { $__componentOriginal7cfab914afdd05940201ca0b2cbc009b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $attributes = $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $component = $__componentOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal19cef05f7817bbe83f5e72b838a9d676 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cef05f7817bbe83f5e72b838a9d676 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.htmx-error-handler','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('htmx-error-handler'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cef05f7817bbe83f5e72b838a9d676)): ?>
<?php $attributes = $__attributesOriginal19cef05f7817bbe83f5e72b838a9d676; ?>
<?php unset($__attributesOriginal19cef05f7817bbe83f5e72b838a9d676); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cef05f7817bbe83f5e72b838a9d676)): ?>
<?php $component = $__componentOriginal19cef05f7817bbe83f5e72b838a9d676; ?>
<?php unset($__componentOriginal19cef05f7817bbe83f5e72b838a9d676); ?>
<?php endif; ?>
        <?php echo $__env->yieldPushContent("footer"); ?>
    </body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>