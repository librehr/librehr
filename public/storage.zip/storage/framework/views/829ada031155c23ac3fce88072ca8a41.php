<div class="my-3 border-b border-gray-200 dark:border-gray-700"></div>
<?php /**PATH /var/www/html/resources/views/components/hr.blade.php ENDPATH**/ ?>