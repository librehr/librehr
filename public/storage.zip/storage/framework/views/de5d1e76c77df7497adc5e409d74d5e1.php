<div class="<?php if(isset($aside)): ?> flex justify-between <?php endif; ?> mb-6">
    <div>
        <?php if(isset($title)): ?>
            <h3 class="text-lg font-medium text-gray-900 dark:text-gray-300">
                <?php echo e($title); ?>

            </h3>
        <?php endif; ?>

        <?php if(isset($description)): ?>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                <?php echo e($description); ?>

            </p>
        <?php endif; ?>
    </div>

    <div>
        <?php if(isset($aside)): ?>
            <?php echo e($aside); ?>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/card-header.blade.php ENDPATH**/ ?>