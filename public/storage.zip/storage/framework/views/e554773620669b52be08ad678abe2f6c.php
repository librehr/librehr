<div x-data="{ deleteAction: '' }">
    <?php if (isset($component)) { $__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> <?php echo e(__("Queues")); ?> <?php $__env->endSlot(); ?>
         <?php $__env->slot('description', null, []); ?> 
            <?php echo e(__("You can manage and create queues for your site via supervisor")); ?>

         <?php $__env->endSlot(); ?>
         <?php $__env->slot('aside', null, []); ?> 
            <?php echo $__env->make("queues.partials.create-queue", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26)): ?>
<?php $attributes = $__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26; ?>
<?php unset($__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26)): ?>
<?php $component = $__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26; ?>
<?php unset($__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal91c4f2e79abed26018755b4f5085cb05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91c4f2e79abed26018755b4f5085cb05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.live','data' => ['id' => 'live-queues']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'live-queues']); ?>
        <div x-data="" class="space-y-3">
            <?php if(count($queues) > 0): ?>
                <?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalb6ba985387b1115985ddfe685275e747 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb6ba985387b1115985ddfe685275e747 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.item-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('item-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div class="flex flex-grow flex-col items-start justify-center">
                            <span class="mb-1 flex items-center lowercase text-red-600">
                                <?php echo e($queue->command); ?>

                            </span>
                            <span class="text-sm text-gray-400"><?php echo e(__("User:")); ?> <?php echo e($queue->user); ?></span>
                        </div>
                        <div class="flex items-center">
                            <?php echo $__env->make("queues.partials.status", ["status" => $queue->status], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div id="queue-actions-<?php echo e($queue->id); ?>" class="inline-flex">
                                <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['id' => 'stop-'.e($queue->id).'','hxPost' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'stop'])).'','hxSwap' => 'outerHTML','hxSelect' => '#queue-actions-'.e($queue->id).'','dataTooltip' => 'Stop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'stop-'.e($queue->id).'','hx-post' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'stop'])).'','hx-swap' => 'outerHTML','hx-select' => '#queue-actions-'.e($queue->id).'','data-tooltip' => 'Stop']); ?>
                                    <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-stop'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['id' => 'resume-'.e($queue->id).'','hxPost' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'start'])).'','hxSwap' => 'outerHTML','hxSelect' => '#queue-actions-'.e($queue->id).'','dataTooltip' => 'Start']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'resume-'.e($queue->id).'','hx-post' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'start'])).'','hx-swap' => 'outerHTML','hx-select' => '#queue-actions-'.e($queue->id).'','data-tooltip' => 'Start']); ?>
                                    <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-play'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['id' => 'restart-'.e($queue->id).'','hxPost' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'restart'])).'','hxSwap' => 'outerHTML','hxSelect' => '#queue-actions-'.e($queue->id).'','dataTooltip' => 'Restart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'restart-'.e($queue->id).'','hx-post' => ''.e(route('servers.sites.queues.action', ['server' => $server, 'site' => $site, 'queue' => $queue, 'action' => 'restart'])).'','hx-swap' => 'outerHTML','hx-select' => '#queue-actions-'.e($queue->id).'','data-tooltip' => 'Restart']); ?>
                                    <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-arrow-path'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['id' => 'logs-'.e($queue->id).'','xOn:click' => '$dispatch(\'open-modal\', \'show-log\'); document.getElementById(\'log-content\').firstChild.innerHTML = \'\';','hxGet' => ''.e(route('servers.sites.queues.logs', ['server' => $server, 'site' => $site, 'queue' => $queue])).'','hxTarget' => '#log-content','hxSelect' => '#log-content','dataTooltip' => 'Logs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'logs-'.e($queue->id).'','x-on:click' => '$dispatch(\'open-modal\', \'show-log\'); document.getElementById(\'log-content\').firstChild.innerHTML = \'\';','hx-get' => ''.e(route('servers.sites.queues.logs', ['server' => $server, 'site' => $site, 'queue' => $queue])).'','hx-target' => '#log-content','hx-select' => '#log-content','data-tooltip' => 'Logs']); ?>
                                    <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-square-3-stack-3d'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['xOn:click' => 'deleteAction = \''.e(route('servers.sites.queues.destroy', ['server' => $server, 'site' => $site, 'queue' => $queue])).'\'; $dispatch(\'open-modal\', \'delete-queue\')','dataTooltip' => 'Delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'deleteAction = \''.e(route('servers.sites.queues.destroy', ['server' => $server, 'site' => $site, 'queue' => $queue])).'\'; $dispatch(\'open-modal\', \'delete-queue\')','data-tooltip' => 'Delete']); ?>
                                    <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-trash'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                            </div>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb6ba985387b1115985ddfe685275e747)): ?>
<?php $attributes = $__attributesOriginalb6ba985387b1115985ddfe685275e747; ?>
<?php unset($__attributesOriginalb6ba985387b1115985ddfe685275e747); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ba985387b1115985ddfe685275e747)): ?>
<?php $component = $__componentOriginalb6ba985387b1115985ddfe685275e747; ?>
<?php unset($__componentOriginalb6ba985387b1115985ddfe685275e747); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <div class="text-center">
                        <?php echo e(__("You don't have any queues yet!")); ?>

                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91c4f2e79abed26018755b4f5085cb05)): ?>
<?php $attributes = $__attributesOriginal91c4f2e79abed26018755b4f5085cb05; ?>
<?php unset($__attributesOriginal91c4f2e79abed26018755b4f5085cb05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91c4f2e79abed26018755b4f5085cb05)): ?>
<?php $component = $__componentOriginal91c4f2e79abed26018755b4f5085cb05; ?>
<?php unset($__componentOriginal91c4f2e79abed26018755b4f5085cb05); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal5b8b2d0f151a30be878e1a760ec3900c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmation-modal','data' => ['name' => 'delete-queue','title' => __('Confirm'),'description' => __('Are you sure that you want to delete this queue?'),'method' => 'delete','xBind:action' => 'deleteAction']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'delete-queue','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Confirm')),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Are you sure that you want to delete this queue?')),'method' => 'delete','x-bind:action' => 'deleteAction']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c)): ?>
<?php $attributes = $__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c; ?>
<?php unset($__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b8b2d0f151a30be878e1a760ec3900c)): ?>
<?php $component = $__componentOriginal5b8b2d0f151a30be878e1a760ec3900c; ?>
<?php unset($__componentOriginal5b8b2d0f151a30be878e1a760ec3900c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'show-log','maxWidth' => '4xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'show-log','max-width' => '4xl']); ?>
        <div class="p-6">
            <h2 class="mb-5 text-lg font-medium text-gray-900 dark:text-gray-100">
                <?php echo e(__("View Log")); ?>

            </h2>
            <div id="log-content">
                <?php if (isset($component)) { $__componentOriginal36ca5329796d87250e5e94de7c0f0259 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36ca5329796d87250e5e94de7c0f0259 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.console-view','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('console-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php if(session()->has("content")): ?>
                        <?php echo e(session("content")); ?>

                    <?php else: ?>
                        Loading...
                    <?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36ca5329796d87250e5e94de7c0f0259)): ?>
<?php $attributes = $__attributesOriginal36ca5329796d87250e5e94de7c0f0259; ?>
<?php unset($__attributesOriginal36ca5329796d87250e5e94de7c0f0259); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36ca5329796d87250e5e94de7c0f0259)): ?>
<?php $component = $__componentOriginal36ca5329796d87250e5e94de7c0f0259; ?>
<?php unset($__componentOriginal36ca5329796d87250e5e94de7c0f0259); ?>
<?php endif; ?>
            </div>
            <div class="mt-6 flex justify-end">
                <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'button','xOn:click' => '$dispatch(\'close\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','x-on:click' => '$dispatch(\'close\')']); ?>
                    <?php echo e(__("Close")); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
</div>
<?php /**PATH /var/www/html/resources/views/queues/partials/queues-list.blade.php ENDPATH**/ ?>