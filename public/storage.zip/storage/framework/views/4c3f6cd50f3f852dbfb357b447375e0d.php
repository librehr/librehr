<p
    <?php echo e($attributes->merge(["class" => "mt-2 text-sm text-gray-500 dark:text-gray-300"])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/input-help.blade.php ENDPATH**/ ?>