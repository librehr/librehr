<?php if (isset($component)) { $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb = $attributes; } ?>
<?php $component = App\View\Components\ServerLayout::resolve(['server' => $server] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('server-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ServerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> <?php echo e(__("Databases")); ?> <?php $__env->endSlot(); ?>

    <div class="space-y-10">
        <?php echo $__env->make("databases.partials.database-list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("databases.partials.database-user-list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make("databases.partials.database-backups", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $attributes = $__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__attributesOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb)): ?>
<?php $component = $__componentOriginal57b712d45e4f3e668116d7d6862ca4fb; ?>
<?php unset($__componentOriginal57b712d45e4f3e668116d7d6862ca4fb); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/databases/index.blade.php ENDPATH**/ ?>