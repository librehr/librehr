<td
    <?php echo $attributes->merge(["class" => "whitespace-nowrap border-t border-gray-200 px-6 py-4 text-gray-700 dark:border-gray-700 dark:text-gray-300 w-1"]); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/td.blade.php ENDPATH**/ ?>