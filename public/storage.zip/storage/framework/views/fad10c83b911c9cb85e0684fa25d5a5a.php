<tbody <?php echo $attributes->merge(["class" => ""]); ?>>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH /var/www/html/resources/views/components/tbody.blade.php ENDPATH**/ ?>