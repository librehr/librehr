<div
    class="rounded-lg border-2 border-yellow-500 border-opacity-50 bg-yellow-50 p-4 text-yellow-500 dark:bg-yellow-500 dark:bg-opacity-10 dark:text-white"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/html/resources/views/components/alert-warning.blade.php ENDPATH**/ ?>