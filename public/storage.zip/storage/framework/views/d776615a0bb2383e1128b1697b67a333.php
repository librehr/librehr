<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "href",
    "type",
    "span",
    "disabled",
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "href",
    "type",
    "span",
    "disabled",
]); ?>
<?php foreach (array_filter(([
    "href",
    "type",
    "span",
    "disabled",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $class =
        "inline-flex h-9 w-max min-w-max items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-1 font-semibold text-gray-700 transition duration-150 ease-in-out hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-25 dark:border-gray-500 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 dark:focus:ring-offset-gray-800";
?>

<?php if(isset($href)): ?>
    <?php if(isset($disabled)): ?>
        <?php
            $class .= " opacity-25 cursor-default";
        ?>

        <span <?php echo e($attributes->merge(["class" => $class])); ?>>
            <?php echo e($slot); ?>

        </span>
    <?php else: ?>
        <a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(["class" => $class])); ?>>
            <?php echo e($slot); ?>

        </a>
    <?php endif; ?>
<?php else: ?>
    <button <?php echo e($attributes->merge(["type" => $type ?? "submit", "class" => $class])); ?>>
        <?php echo e($slot); ?>

    </button>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/secondary-button.blade.php ENDPATH**/ ?>