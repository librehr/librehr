<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "id",
    "name",
    "disabled" => false,
    "lang" => "text",
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "id",
    "name",
    "disabled" => false,
    "lang" => "text",
]); ?>
<?php foreach (array_filter(([
    "id",
    "name",
    "disabled" => false,
    "lang" => "text",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div
    x-data="{
        editorId: <?php echo \Illuminate\Support\Js::from($id)->toHtml() ?>,
        disabled: <?php echo \Illuminate\Support\Js::from($disabled)->toHtml() ?>,
        lang: <?php echo \Illuminate\Support\Js::from($lang)->toHtml() ?>,
        init() {
            document.body.addEventListener('htmx:afterSettle', (event) => {
                let editor = null
                let theme =
                    document.documentElement.className === 'dark'
                        ? 'one-dark'
                        : 'github'
                editor = window.ace.edit(this.editorId, {})
                let contentElement = document.getElementById(
                    `text-${this.editorId}`,
                )
                editor.setValue(contentElement.innerText, 1)
                if (this.disabled) {
                    editor.setReadOnly(true)
                }
                editor.getSession().setMode(`ace/mode/${this.lang}`)
                editor.setTheme(`ace/theme/${theme}`)
                editor.setFontSize('15px')
                editor.setShowPrintMargin(false)
                editor.on('change', () => {
                    contentElement.innerHTML = editor.getValue()
                })
                document.body.addEventListener('color-scheme-changed', (event) => {
                    theme = event.detail.theme === 'dark' ? 'one-dark' : 'github'
                    editor.setTheme(`ace/theme/${theme}`)
                })
            })
        },
    }"
>
    <div id="<?php echo e($id); ?>" class="min-h-[400px] w-full rounded-md border border-gray-200 dark:border-gray-700"></div>
    <textarea id="text-<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="hidden"><?php echo e($slot); ?></textarea>
</div>
<?php /**PATH /var/www/html/resources/views/components/code-editor.blade.php ENDPATH**/ ?>