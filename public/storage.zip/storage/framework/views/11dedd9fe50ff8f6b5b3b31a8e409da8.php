<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "disabled" => false,
    "id",
    "name",
    "value",
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "disabled" => false,
    "id",
    "name",
    "value",
]); ?>
<?php foreach (array_filter(([
    "disabled" => false,
    "id",
    "name",
    "value",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="flex items-center">
    <input
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        type="checkbox"
        value="<?php echo e($value); ?>"
        <?php echo e($attributes->merge(["disabled" => $disabled, "class" => "rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:border-gray-700 dark:bg-gray-900 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"])); ?>

    />
    <label for="<?php echo e($id); ?>" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">
        <?php echo e($slot); ?>

    </label>
</div>
<?php /**PATH /var/www/html/resources/views/components/checkbox.blade.php ENDPATH**/ ?>