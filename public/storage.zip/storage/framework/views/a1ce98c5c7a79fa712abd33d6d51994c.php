<div class="my-3 border-b border-gray-200 dark:border-gray-700"></div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/hr.blade.php ENDPATH**/ ?>