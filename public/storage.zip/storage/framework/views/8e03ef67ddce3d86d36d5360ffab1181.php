<?php echo $__env->make("sites.partials.create.fields.php-version", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make("sites.partials.create.fields.web-directory", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/sites/partials/create/php-blank.blade.php ENDPATH**/ ?>