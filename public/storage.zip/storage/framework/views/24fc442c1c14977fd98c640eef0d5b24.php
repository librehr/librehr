<div>
    <?php if (isset($component)) { $__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> Source Controls <?php $__env->endSlot(); ?>
         <?php $__env->slot('description', null, []); ?> You can connect your source controls via API Tokens <?php $__env->endSlot(); ?>
         <?php $__env->slot('aside', null, []); ?> 
            <?php echo $__env->make("settings.source-controls.partials.connect", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26)): ?>
<?php $attributes = $__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26; ?>
<?php unset($__attributesOriginalf8fdb5e325b86ec4fcbd12174b8a2d26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26)): ?>
<?php $component = $__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26; ?>
<?php unset($__componentOriginalf8fdb5e325b86ec4fcbd12174b8a2d26); ?>
<?php endif; ?>
    <div x-data="{ deleteAction: '' }" class="space-y-3">
        <?php if(count($sourceControls) > 0): ?>
            <?php $__currentLoopData = $sourceControls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sourceControl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalb6ba985387b1115985ddfe685275e747 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb6ba985387b1115985ddfe685275e747 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.item-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('item-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <div class="flex-none text-gray-600 dark:text-gray-300">
                        <?php echo $__env->make("settings.source-controls.partials.icons." . $sourceControl->provider . "-icon", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="ml-3 flex flex-grow flex-col items-start justify-center">
                        <span class="mb-1"><?php echo e($sourceControl->profile); ?></span>
                        <span class="text-sm text-gray-400">
                            <?php if (isset($component)) { $__componentOriginal8319e42702f02703b9e1bc5b0dc5413c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8319e42702f02703b9e1bc5b0dc5413c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.datetime','data' => ['value' => $sourceControl->created_at]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sourceControl->created_at)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8319e42702f02703b9e1bc5b0dc5413c)): ?>
<?php $attributes = $__attributesOriginal8319e42702f02703b9e1bc5b0dc5413c; ?>
<?php unset($__attributesOriginal8319e42702f02703b9e1bc5b0dc5413c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8319e42702f02703b9e1bc5b0dc5413c)): ?>
<?php $component = $__componentOriginal8319e42702f02703b9e1bc5b0dc5413c; ?>
<?php unset($__componentOriginal8319e42702f02703b9e1bc5b0dc5413c); ?>
<?php endif; ?>
                        </span>
                    </div>
                    <div class="flex items-center">
                        <div class="inline">
                            <?php if (isset($component)) { $__componentOriginal658398a0e73a18931bb7def04d911f42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal658398a0e73a18931bb7def04d911f42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-button','data' => ['xOn:click' => 'deleteAction = \''.e(route('source-controls.delete', $sourceControl->id)).'\'; $dispatch(\'open-modal\', \'delete-source-control\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'deleteAction = \''.e(route('source-controls.delete', $sourceControl->id)).'\'; $dispatch(\'open-modal\', \'delete-source-control\')']); ?>
                                <?php if (isset($component)) { $__componentOriginal058f71a6e8b137b894618c0554a4ae6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a = $attributes; } ?>
<?php $component = App\View\Components\Heroicon::resolve(['name' => 'o-trash'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heroicon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $attributes = $__attributesOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__attributesOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a)): ?>
<?php $component = $__componentOriginal058f71a6e8b137b894618c0554a4ae6a; ?>
<?php unset($__componentOriginal058f71a6e8b137b894618c0554a4ae6a); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $attributes = $__attributesOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__attributesOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal658398a0e73a18931bb7def04d911f42)): ?>
<?php $component = $__componentOriginal658398a0e73a18931bb7def04d911f42; ?>
<?php unset($__componentOriginal658398a0e73a18931bb7def04d911f42); ?>
<?php endif; ?>
                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb6ba985387b1115985ddfe685275e747)): ?>
<?php $attributes = $__attributesOriginalb6ba985387b1115985ddfe685275e747; ?>
<?php unset($__attributesOriginalb6ba985387b1115985ddfe685275e747); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ba985387b1115985ddfe685275e747)): ?>
<?php $component = $__componentOriginalb6ba985387b1115985ddfe685275e747; ?>
<?php unset($__componentOriginalb6ba985387b1115985ddfe685275e747); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo $__env->make("settings.source-controls.partials.delete-source-control", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginald48eac130f464767af4133313bc76a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald48eac130f464767af4133313bc76a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('simple-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="text-center">
                    <?php echo e(__("You haven't connected to any server source controls yet!")); ?>

                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $attributes = $__attributesOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__attributesOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald48eac130f464767af4133313bc76a5f)): ?>
<?php $component = $__componentOriginald48eac130f464767af4133313bc76a5f; ?>
<?php unset($__componentOriginald48eac130f464767af4133313bc76a5f); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/settings/source-controls/partials/source-controls-list.blade.php ENDPATH**/ ?>