<thead
    <?php echo $attributes->merge(["class" => "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 border-b border-gray-200 dark:border-gray-600"]); ?>

>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH /var/www/html/resources/views/components/thead.blade.php ENDPATH**/ ?>