<?php
    $class = "mx-auto px-4 sm:px-6 lg:px-8";
    if (! str($attributes->get("class"))->contains("max-w-")) {
        $class .= " max-w-7xl";
    }
?>

<div <?php echo $attributes->merge(["class" => $class]); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/container.blade.php ENDPATH**/ ?>