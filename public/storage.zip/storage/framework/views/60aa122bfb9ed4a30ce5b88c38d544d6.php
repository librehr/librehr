<div
    <?php echo e($attributes->merge(["class" => "relative h-[500px] w-full overflow-auto whitespace-pre-line rounded-md border border-gray-200 bg-black p-5 text-gray-50 dark:border-gray-700"])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/libra/Proyectos/vito/resources/views/components/console-view.blade.php ENDPATH**/ ?>